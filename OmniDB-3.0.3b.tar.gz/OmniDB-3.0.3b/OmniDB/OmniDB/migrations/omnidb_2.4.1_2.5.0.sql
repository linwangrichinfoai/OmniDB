UPDATE db_type SET dbt_in_enabled = 1 WHERE dbt_st_name = 'oracle';--omnidb--

UPDATE version SET ver_id = '2.5.0';--omnidb--
