UPDATE mon_units SET is_default = 0;--omnidb--

UPDATE version SET ver_id = '2.14.2';--omnidb--
