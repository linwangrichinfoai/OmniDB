from django.apps import AppConfig


class OmnidbAppConfig(AppConfig):
    name = 'OmniDB_app'
